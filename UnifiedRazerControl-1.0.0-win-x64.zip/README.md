# Unified Razer Control

A small, open-source Windows alternative to Razer Synapse for **two devices only**:

- **Razer Viper 8KHz** (wired, USB `1532:0091`)
- **Razer BlackShark V2 Pro (2023)** through its **2.4 GHz USB dongle** (USB `1532:0555`)

User-mode HID only: no drivers, no kernel components, no services, no admin rights, no account, no cloud, no telemetry.
**Not affiliated with or endorsed by Razer Inc.** "Razer", "Viper" and "BlackShark" are Razer's trademarks, used
only to say which hardware this works with.

## What it does

| Device | Features |
|---|---|
| Viper 8KHz | DPI stages (up to 5) and active stage, current DPI, polling rate (125–8000 Hz), logo brightness |
| Viper 8KHz side buttons | **Toggle clickers**: press MB4/MB5 once to start, again to stop. *Repeat* (click every N ms) or *Hold* (keep the button held down) for left/right/middle, with an optional auto-stop |
| BlackShark V2 Pro | EQ presets (Game, Music, Movie, Custom, Esports 1–5), 10-band custom EQ (−12..+12 dB), battery |
| BlackShark V2 Pro | **EQ lock**: keeps the headset on one preset. If the EQ button (or anything else) changes it, it's switched back within a few seconds |
| Background | Tray icon, start with Windows, about 12 MB private memory, ~0% CPU while idle |

Every setting written to a device is **read back** to confirm it took. Nothing is ever written to firmware, and the
button mappings stored on the mouse (including Synapse macros) are never changed.

## Install

1. Install the [.NET 8 Desktop Runtime (x64)](https://dotnet.microsoft.com/download/dotnet/8.0) if you don't have it.
2. Download `UnifiedRazerControl-<version>-win-x64.zip` from Releases and extract it anywhere (for example `%LOCALAPPDATA%\UnifiedRazerControl`).
3. Run **`urc-app.exe`**. It starts the background agent (`urc-agent.exe`, tray icon) by itself.
4. In the app, under **General**, turn on **Start the background agent with Windows** if you want it at login.

Windows SmartScreen may warn about an unknown publisher because the files aren't code-signed. The source is all here, so you can build it yourself instead (below).

**Synapse:** you don't need to uninstall it. If it's running it may overwrite changes made here, so quit it
(or remove it from startup) for the best results.

## Use

- **App window** (`urc-app.exe`): Mouse, Clickers, Headset and General tabs. Closing it frees its memory; the agent keeps running.
- **Tray icon** (right-click): open the app, turn the clickers or the EQ lock on/off, stop all clickers now, start with Windows, exit.
- **Safety:** all clickers stop (and any held button is released) when you lock the PC, log off, the PC sleeps, or the agent exits.
- **Command line** (`urc.exe`, optional): `urc mouse show`, `urc mouse dpi 1600`, `urc headset preset game`, `urc headset eq 3,2,0,0,0,0,0,1,2,3`, `urc agent`, ... Run `urc` for the full list.
- **Diagnostics** (`urc-diag.exe`, read-only): `urc-diag report` writes `urc-diag-report.json`. It includes device serial numbers, so remove them before posting it anywhere.

Settings live in `%APPDATA%\UnifiedRazerControl\settings.json`, and the agent's log is in `agent.log` next to it.

### Limits and caveats

- Only these two exact devices. Other Razer devices are detected and **never opened**.
- The headset works only through the 2.4 GHz dongle; over Bluetooth it can't be reached. There's no volume control over HID; use the headset's wheel.
- Clicker clicks are software input (`SendInput`). Windows marks them as injected. **Some games and anti-cheat systems ignore or punish this; check the rules before using it online.** Windows running as administrator don't receive them.
- The minimum clicker interval is 5 ms. Faster than that, apps can't keep up and keep "clicking" after you stop.
- Tested on one Viper 8KHz (firmware v1.3) and one BlackShark V2 Pro (dongle firmware 2.6) on Windows 11. See [docs/RESEARCH.md](docs/RESEARCH.md) for exactly what was verified.

## Build from source

Requires the .NET 8 SDK on Windows.

```
dotnet build -c Release
dotnet test -c Release
powershell -ExecutionPolicy Bypass -File build/package.ps1     # writes artifacts/UnifiedRazerControl-<version>-win-x64.zip
```

Projects: `Urc.Core` (protocols, HID, clicker engine, EQ lock, agent logic), `Urc.Tray` (`urc-agent.exe`),
`Urc.App` (`urc-app.exe`, WPF), `Urc.Agent` (`urc.exe`, CLI), `Urc.Diag` (`urc-diag.exe`). Design: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## License and credits

GPL-2.0-or-later (see [LICENSE](LICENSE)). The protocol knowledge comes from
[OpenRazer](https://github.com/openrazer/openrazer), [OpenRazer PR #2862](https://github.com/openrazer/openrazer/pull/2862),
[blackshark-control](https://github.com/AbdullahSAhmad/blackshark-control) and [OpenSynapse](https://github.com/JohnsonRan/OpenSynapse),
all GPL-2.0-or-later. It was reimplemented in C#, and the credit for the reverse engineering belongs to those projects.
