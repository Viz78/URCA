# Handoff: continue Unified Razer Control on the user's PC

Read this first, then `README.md`, `docs/RESEARCH.md` and `docs/ARCHITECTURE.md`.

## Goal
A lightweight Windows replacement for Razer Synapse for exactly two devices:
- Razer Viper 8KHz, USB 1532:0091 (hardware ID `HID\VID_1532&PID_0091&REV_0101&MI_00`)
- Razer BlackShark V2 Pro 2023 (RZ04-04530100), 2.4 GHz dongle USB 1532:0555

Stack: C# / .NET 8, user-mode Win32 HID only (no drivers), WPF UI later, local JSON settings.
Milestones: 1 detection/communication → 2 mouse config + MB4/MB5 toggle clickers → 3 headset EQ + Game-EQ lock
→ 4 unified UI → 5 optimization/background/startup. Work incrementally; after each milestone say what works,
what doesn't, and how to test. Never invent HID commands, never write firmware, never remove Synapse.

## Where things stand
- **Milestone 1 is implemented and builds (21 unit tests pass), but has NOT been run on real hardware.**
  It was developed in a Linux cloud container with no access to the devices.
- `urc-diag.exe` is a read-only diagnostic (`scan`, `viper [--probe-buttons]`, `headset`, `watch [s]`, `report`).
  Double-clicked, it runs `report` and stays open.
- On the previous PC the user reported that it "wasn't launching". The exact symptom is unknown. The
  double-click fix was the likely cause. Defender/SmartScreen blocking the unsigned exe is the other suspect.

## First things to do on this PC
1. `dotnet --list-sdks`: install the .NET 8 SDK if it's missing.
2. `dotnet build -c Release` and `dotnet test -c Release` from the repo root.
3. `dotnet run --project src/Urc.Diag -c Release -- scan`, then `viper`, `headset`, `watch 30` (ask the user to
   press the headset EQ/SmartSwitch button during `watch`), and optionally `viper --probe-buttons` (one unverified,
   read-only Synapse-4 button-list query).
4. Record the results: which collection is the headset's control interface (expected vendor page 0xFF00,
   64/64 reports, output report ID 2, probably MI_03 but unconfirmed), whether the Viper answers on MI_00
   with 91-byte feature reports, firmware versions, and whether button presses arrive as unsolicited 0x13 frames.
5. Report these to the user, update docs/RESEARCH.md with what's verified, and only then start Milestone 2.
   Writes need the user's OK and should be read back to verify.

## Key protocol facts and risks
See docs/RESEARCH.md. In short:
- Viper polling-rate set is sent twice (arg0 00/txn 1F, then arg0 01/txn FF).
- Viper onboard button remapping is unverified. Fall back to software remapping (WH_MOUSE_LL).
- Headset: an ACK doesn't prove a setting took (read back). Writing a custom EQ curve during a preset-family
  transition corrupts another preset. There's no HID volume command. Bluetooth is out of scope.

## Repository
Intended home: GitHub `Viz78/URCA`. As of this handoff the code hadn't been pushed there; it was delivered as
`UnifiedRazerControl-src.zip` / `UnifiedRazerControl.bundle`.
