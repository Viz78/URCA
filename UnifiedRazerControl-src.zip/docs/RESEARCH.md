# Research: existing open-source work

Inspected on 2026-11-23 by cloning each repository and reading the code (not just READMEs).

## Repository status

| Project | Available | License | Platform / language | Relevant to |
|---|---|---|---|---|
| [OpenRazer](https://github.com/openrazer/openrazer) | Yes (active, last commit 2026-11-18) | GPL-2.0-or-later (docs CC-BY-SA-4.0) | Linux kernel driver (C) + Python daemon | **Viper 8KHz (PID 0091): merged support** |
| [OpenRazer PR #2862](https://github.com/openrazer/openrazer/pull/2862) | Yes, **open / not merged** | GPL-2.0-or-later | Linux kernel driver | **BlackShark V2 Pro 2.4 (PID 0555)** |
| [blackshark-control](https://github.com/AbdullahSAhmad/blackshark-control) | Yes (2026-10-13) | GPL-2.0-or-later | Linux, Python, user-space hidraw | **BlackShark V2 Pro 2023 (PID 0555)**, tested on firmware 2.5 |
| [OpenSynapse](https://github.com/JohnsonRan/OpenSynapse) | Yes (v0.10.0, 2026-11-14) | Source GPL-2.0-or-later; release binaries GPL-3.0 (embedded VIA data) | **Windows**, Go + WebView2 | Viper 8K via an OpenRazer-generated catalog; Windows HID transport; macros |
| Non-Synapse-Mouse (edward-p) | **No.** The URL returns 404 and the owner's 36 public repos contain nothing Razer-related | — | — | Nothing could be evaluated |

## Viper 8KHz (1532:0091)

**Source of truth:** OpenRazer `driver/razermouse_driver.c`, every `case USB_DEVICE_ID_RAZER_VIPER_8K` block,
plus `daemon/openrazer_daemon/hardware/mouse.py` class `RazerViper8KHz`.

Features the driver exposes for this PID: firmware, serial, device mode, DPI X/Y, DPI stages (max 5),
polling rate (125/500/1000/2000/4000/8000), logo LED brightness, and logo effects (static, spectrum, reactive,
breath, none). Max DPI 20000.

| Function | Class:Cmd | Size | Txn ID | Notes |
|---|---|---|---|---|
| Firmware (get) | 00:81 | 02 | FF | |
| Serial (get) | 00:82 | 16 | FF | |
| Device mode (get / set) | 00:84 / 00:04 | 02 | FF | We do **not** switch to driver mode (0x03); it changes how the mouse's own buttons behave |
| DPI (get) | 04:85 | 07 | FF | arg0 = NOSTORE |
| DPI (set) | 04:05 | 07 | FF | builder always writes VARSTORE |
| DPI stages (get / set) | 04:86 / 04:06 | 26 | FF | VARSTORE, stride 7 |
| Polling rate (get) | 00:C0 | 01 | 1F | "polling_rate2" codes: 01=8000 02=4000 04=2000 08=1000 10=500 40=125 |
| Polling rate (set) | 00:40 | 02 | 1F, then FF | **Sent twice**: arg0=00 with txn 1F, then arg0=01 with txn FF (driver comment: "Razer sends each request once with 0x00 and once with 0x01") |
| Logo brightness (get/set) | 0F:84 / 0F:04 | 03 | 1F | led 0x04 |
| Logo static | 0F:02 | 09 | 1F | [VARSTORE, 04, 01, 00, 00, 01, R, G, B] |

Transport: USB control SET_REPORT/GET_REPORT, report type Feature, wValue 0x0300, **wIndex 0 (interface 0)**,
600 µs wait. The PID isn't in any of the "longer wait / index 3" special cases.
OpenSynapse's `devices.json` (generated from OpenRazer commit 477f4d6) lists byte-identical transaction IDs
and the same two-step polling sequence for "0091". The two sources agree.

**Windows mapping** (from OpenSynapse `internal/razer/hid_windows.go`): open the HID collection whose
FeatureReportByteLength = 91 with `CreateFile(access = 0)`. Windows allows that even though it owns the mouse
collection. Then use `HidD_SetFeature` + `HidD_GetFeature` with byte 0 = report ID 0. CRC = XOR of buffer bytes 3..88.

**Button remapping: no verified source for PID 0091.** OpenRazer has no button remapping for any mouse.
OpenSynapse has onboard remapping (class 02, cmd 84/8C/0C, taken from Synapse 4), but its own comment says
"only been tried on the DeathAdder V4 Pro; a device without them does not answer". It only enables extras for
that model family. So: onboard remapping on the Viper 8K is **unknown**. `urc-diag viper --probe-buttons`
sends the read-only button-list query once to find out. Until it is verified, remapping is done in software (see ARCHITECTURE.md).

**Not verified by any source:** whether OpenRazer maintainers tested every function on real 0091 hardware.
Support is merged, but Milestone 1 confirms each read on your unit.

## BlackShark V2 Pro 2023 (1532:0555)

**Sources:** blackshark-control `blackshark/protocol.py` (tested on Linux Mint, headset firmware 2.5) and
OpenRazer PR #2862 `driver/razerblackshark_driver.{c,h}` (open; derived from Synapse USB captures of this device).
blackshark-control credits PR #2862 for the protocol. These are not independent confirmations; they come from one capture effort.

Transport: the dongle's vendor HID interface (usage page 0xFF00), **report ID 2, 64-byte reports**. Requests are
**output** reports on the interrupt OUT endpoint, replies are **input** reports (PR #2862 header). The interface
number isn't stated (the PR's event regex suggests if03). The Windows module therefore selects the collection by
its descriptor (vendor page, 64/64 input/output, output report ID 2), not by a hard-coded MI number.

Frame: `[0]=02 [1]=80 [2]=8+len [5]='P' [6]='A' [7]=08 [9]=type [10]=cmd [11]=0 [12]=len [13..]=payload`.
Reply: `[12]=cmd [13]=01 (ACK) [14]=len [15..]`. "Remote" frame `[7]=0E [9]=02 [10]=E1 [11]=on/off` wraps every exchange.

| Feature | Read | Write | Status |
|---|---|---|---|
| EQ preset Game 07 / Music 08 / Movie 09 / Custom FF / Esports FA–FE | 03:13 | 04:93 + 04:9D (+ prep 03:1E) | Supported. Verify by reading back |
| 10-band custom EQ (−12..+12 dB, 31 Hz–16 kHz) | 03:15 | 0D:95 | Supported. **Danger:** a 0x95 frame sent during a cross-family transition overwrites another preset's curve (observed by PR author). Custom must be confirmed active first |
| Game/Music/Movie curves | — | — | Built into firmware; the curves **cannot be read back** |
| Physical EQ button | unsolicited 0x13 frame | — | This is the hook for **EQ locking** |
| Battery %, charging | 21, 2A | — | Supported |
| Mic mute state | 55 | — | Read only |
| Mic monitoring | 18/19 | 98/99 | Supported |
| Auto power-off | 2C | AC | 15–60 min or never |
| Bluetooth do-not-disturb | 27 | A7 | Exists. Not exposed (Bluetooth-related, not needed) |
| **Volume** | — | — | **No HID volume command is known.** The volume wheel works inside the headset and isn't reported over the dongle. PC-side volume can use the standard Windows Core Audio endpoint API (not a device protocol) |
| THX Spatial | — | — | Proprietary Synapse software; not available |

Behavioral warnings from PR #2862: the 2.4 GHz link dozes after about 0.3 s and drops the first frame (so a sacrificial
remote frame is sent first). "An ACK from this device does not on its own mean the setting took." Command 0x9D
"neither stores nor acts on it". It is still part of Synapse's apply sequence and is mirrored as captured.

**Bluetooth vs 2.4 GHz:** everything above goes through the USB dongle only. When the headset is used over
Bluetooth (to a phone or the PC's BT stack), the dongle can't reach it and no setting can be read or written.
This project never talks to the Bluetooth side.

## Reuse decision

- License: **GPL-2.0-or-later**, compatible with all three usable sources.
- No source files were copied (the sources are C, Python and Go). The protocol constants, frame layouts and
  command sequences were reimplemented in C# from the code above, with file/line attribution in comments.
- OpenSynapse's Windows approach was adopted as a design: zero-access feature-report handles, serialized set/get,
  and Busy handling.
