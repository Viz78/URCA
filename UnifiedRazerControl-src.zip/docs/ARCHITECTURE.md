# Architecture (proposed; Milestone 1 implements the bottom two layers)

```
┌───────────────────────────── Urc.App (WPF, optional) ───────────────────────────┐
│ Device pages · DPI/polling/lighting · button bindings · EQ · settings            │
│ Separate process, started from the tray on demand; closing it frees all its RAM. │
└───────────────▲─────────────────────────────────────────────────────────────────┘
                │ named pipe (\\.\pipe\urc-agent), small JSON messages
┌───────────────┴──────────── Urc.Agent (background, Native AOT) ─────────────────┐
│ Tray icon (raw Win32 Shell_NotifyIcon, no UI framework)                          │
│ DeviceManager: WM_DEVICECHANGE (HID interface GUID) → open/close modules         │
│ MacroEngine:   WH_MOUSE_LL hook thread + SendInput clicker thread                │
│ EqLockService: unsolicited 0x13 → restore Game preset (read-back verified)      │
│ SettingsStore: %APPDATA%\UnifiedRazerControl\settings.json (source-gen JSON)    │
└───────────────▲─────────────────────────────────────────────────────────────────┘
                │
┌───────────────┴──────────── Urc.Core (library) ─────────────────────────────────┐
│ Devices/  Viper8KDevice · BlackSharkV2ProDevice          ← Milestone 1 (reads) │
│ Protocol/ RazerReport · Viper8KProtocol · BlackSharkProtocol (pure, tested)     │
│ Hid/      HidEnumerator · HidFeatureChannel · HidReportChannel (Win32, user mode)│
└─────────────────────────────────────────────────────────────────────────────────┘
```

## Why this shape

- **Low background cost.** Only the agent stays running. It's Native-AOT compiled, with no WPF and no WebView, and it
  blocks in the kernel waiting for input (no polling loops). Target: well under 20 MB working set and ~0% idle CPU.
  The WPF UI loads only while you're using it.
- **No service, no driver, no admin.** Low-level input hooks and SendInput must run in your interactive desktop
  session, so a Windows service is the wrong tool. The agent starts via `HKCU\...\Run`.
- **Device isolation.** A module only opens a collection whose descriptor matches what the protocol needs
  (Viper: MI_00 + 91-byte feature report. BlackShark: vendor page + 64/64 reports + output ID 2). No other HID
  device is opened. Enumeration reads paths only.
- **Coexistence.** Handles are opened shared. Synapse is never stopped or uninstalled. The app warns if Synapse
  is running, because both write the same settings.

## Planned behavior of later modules

**Macro engine (software, independent of the mouse's onboard memory)**
- WH_MOUSE_LL hook sees XBUTTON1/XBUTTON2 (MB4/MB5) and swallows them when bound to a macro.
  Our own injected events are ignored by checking `LLMHF_INJECTED`.
- Toggle: press → start clicker, press again → stop. Interval configurable (floor around 1 ms; Windows timer
  resolution applies), click type left/right/middle.
- Safeguards: one global "stop all" path called on agent exit, session lock/logoff, mouse disconnect
  (device-change notification), and a hotkey. The clicker always sends a matching *up* after every *down*,
  so a button can never be left logically held. Optional max-duration auto-stop.
- Keyboard combinations through SendInput with paired key-up on every exit path.
- Limitations: injected input is flagged as injected. Some games and anti-cheat systems ignore or penalize it, so check
  the game's rules. Elevated (admin) windows don't receive input from a non-elevated agent.

**Button remapping**
- Onboard (stored in the mouse) only if the `--probe-buttons` result shows the Viper 8K answers the Synapse-4
  button commands. That needs testing on your unit first.
- Otherwise in software: the same hook rewrites MB4/MB5/middle into other buttons or key combos. This only works while
  the agent is running.

**EQ lock**
- Listens for the unsolicited `0x13` frame (button press). If the new preset isn't Game, the agent waits briefly
  (debounce), sends the Game preset apply sequence, and reads back `0x13` until it confirms. A lock on the agent's own
  writes prevents feedback loops, and a retry cap prevents fighting the firmware.
- If the headset is on Bluetooth only, the dongle sees nothing and the lock is inactive. The UI shows this.
