# Unified Razer Control

A lightweight, open-source Windows replacement for Razer Synapse, for two devices only:

- **Razer Viper 8KHz** — USB `1532:0091`
- **Razer BlackShark V2 Pro (2023)** through its 2.4 GHz dongle — USB `1532:0555`

It uses user-mode HID only: no drivers, no kernel components, no Synapse, no account, no cloud.
It is not affiliated with Razer Inc.

See [docs/RESEARCH.md](docs/RESEARCH.md) for the protocol sources and compatibility limits, and
[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the design.

## Status

| Milestone | State |
|---|---|
| 1. Hardware detection & communication | **Implemented, not yet verified on real hardware.** Read-only diagnostic tool |
| 2. Mouse configuration | Not started |
| 3. Headset configuration / EQ lock | Not started |
| 4. Unified interface | Not started |
| 5. Optimization / background / startup | Not started |

## Build

Requires the .NET 8 SDK.

```
dotnet build -c Release
dotnet test -c Release
dotnet publish src/Urc.Diag -c Release -r win-x64 --self-contained false -p:PublishSingleFile=true -o artifacts/urc-diag-win-x64
```

`Urc.Core` and the tests build on any OS. The protocol tests run anywhere. Talking to the hardware needs Windows 10/11.

## Milestone 1: testing on your PC

`urc-diag` **only reads**. Every mouse command it sends is a GET (command ID bit 7 set, enforced by a unit test).
The headset commands are queries wrapped in the same "remote" frames Synapse uses for reading.
No setting is changed, and nothing is written to device memory or firmware.

1. Use the self-contained `urc-diag.exe` (no install needed), or the small framework-dependent build with the [.NET 8 Runtime](https://dotnet.microsoft.com/download/dotnet/8.0).
2. Plug in the mouse and the headset dongle, and turn the headset on (2.4 GHz mode, not Bluetooth).
3. Synapse can stay installed. Reading works alongside it. Quitting it gives the cleanest result.
4. In a normal (non-admin) terminal:

```
urc-diag scan
urc-diag viper
urc-diag headset
urc-diag watch 30
urc-diag viper --probe-buttons
urc-diag report --probe-buttons
```

- `scan` lists every HID collection of both devices: interface (MI_xx), usage page, report lengths and report IDs,
  and which collection would be used for control. A device with no matching collection is left alone.
- `viper` reads the firmware, serial, device mode, current DPI, DPI stages, polling rate and logo brightness.
- `headset` reads the firmware, battery, charging state, EQ preset and curve, mic mute, mic monitoring, auto-off and BT DND.
- `watch 30` listens for 30 s without sending anything. Press the headset's EQ/SmartSwitch button a few times.
  Each press should print `EQ preset changed -> ...`. That confirms the detection Milestone 3 needs for EQ locking.
- `viper --probe-buttons` is optional. It sends one read-only Synapse-4 "list buttons" query, which is unverified on this mouse,
  to find out whether onboard button remapping is possible.
- `report` runs everything and writes `urc-diag-report.json`. It contains serial numbers, so redact them before sharing.

What to check:
- The Viper values match what Synapse shows (DPI stages, polling rate).
- Changing the preset with the headset button, then running `urc-diag headset`, shows the new preset.
- Unplugging the dongle during `watch` prints `DONGLE DISCONNECTED`.

## License

GPL-2.0-or-later (see [LICENSE](LICENSE)). The protocol knowledge comes from OpenRazer, OpenRazer PR #2862,
blackshark-control and OpenSynapse, all GPL-2.0-or-later. It was reimplemented in C#. Credit for the reverse
engineering belongs to those projects.
