namespace Urc.Core.Protocol;

/// <summary>
/// Razer Viper 8KHz (USB 1532:0091) commands, taken from the PID-0091 code paths of the OpenRazer kernel
/// driver (driver/razermouse_driver.c, case USB_DEVICE_ID_RAZER_VIPER_8K) and builders in
/// driver/razerchromacommon.c. Cross-checked against OpenSynapse's generated catalog for "0091"
/// (internal/razer/data/devices.json, generated from OpenRazer commit 477f4d6).
///
/// Transport: SET_REPORT/GET_REPORT feature, report ID 0, wIndex = interface 0 (default branch of
/// razer_get_report → index 0, RAZER_MOUSE_WAIT_US = 600 µs). On Windows: HidD_SetFeature/GetFeature on
/// the MI_00 collection whose FeatureReportByteLength is 91.
///
/// MILESTONE 1 CONTAINS READ (GET, command id bit 7 set) COMMANDS ONLY. Nothing here changes device state.
/// </summary>
public static class Viper8KProtocol
{
    public const ushort ProductId = 0x0091;
    public const int MaxDpi = 20000;        // OpenRazer daemon RazerViper8KHz.DPI_MAX
    public const int MaxDpiStages = 5;      // RAZER_MOUSE_MAX_DPI_STAGES
    public static readonly int[] PollRates = [125, 500, 1000, 2000, 4000, 8000]; // daemon POLL_RATES

    public const byte NoStore = 0x00, VarStore = 0x01, LogoLed = 0x04;

    // Per-command transaction IDs for PID 0091 (OpenRazer case blocks; identical in OpenSynapse catalog).
    private const byte TxFF = 0xFF, Tx1F = 0x1F;

    /// <summary>00:81 firmware version → v{args[0]}.{args[1]}</summary>
    public static RazerReport GetFirmware() => RazerReport.Request(TxFF, 0x00, 0x81, 0x02);

    /// <summary>00:82 serial, 22 bytes ASCII</summary>
    public static RazerReport GetSerial() => RazerReport.Request(TxFF, 0x00, 0x82, 0x16);

    /// <summary>00:84 device mode → args[0] (0x00 normal, 0x03 driver mode), args[1]</summary>
    public static RazerReport GetDeviceMode() => RazerReport.Request(TxFF, 0x00, 0x84, 0x02);

    /// <summary>04:85 current DPI, NOSTORE → X = args[1..2] BE, Y = args[3..4] BE</summary>
    public static RazerReport GetDpi() => RazerReport.Request(TxFF, 0x04, 0x85, 0x07, NoStore);

    /// <summary>04:86 DPI stages, VARSTORE → see <see cref="ParseDpiStages"/></summary>
    public static RazerReport GetDpiStages() => RazerReport.Request(TxFF, 0x04, 0x86, 0x26, VarStore);

    /// <summary>00:C0 polling rate ("polling_rate2" family) → args[1] code, see <see cref="DecodePollRate"/></summary>
    public static RazerReport GetPollRate() => RazerReport.Request(Tx1F, 0x00, 0xC0, 0x01);

    /// <summary>0F:84 logo LED brightness, VARSTORE → args[2] (0–255)</summary>
    public static RazerReport GetLogoBrightness() => RazerReport.Request(Tx1F, 0x0F, 0x84, 0x03, VarStore, LogoLed);

    /// <summary>
    /// 02:84 "list remappable buttons". NOT from OpenRazer: from OpenSynapse internal/razer/buttons.go
    /// (Synapse 4 command, only tried on the DeathAdder V4 Pro). Read-only GET; a device that lacks it
    /// answers Not Supported or not at all. Used only behind an explicit opt-in diagnostic flag to find out
    /// whether the Viper 8K supports onboard remapping. Unverified on PID 0091.
    /// </summary>
    public static RazerReport ProbeButtonList() => RazerReport.Request(Tx1F, 0x02, 0x84, 0x50);

    // ---- decoders -------------------------------------------------------------------------

    public static string ParseFirmware(RazerReport r) => $"v{r.Args[0]}.{r.Args[1]}";

    public static string ParseSerial(RazerReport r)
    {
        var a = r.Args[..22];
        int z = a.IndexOf((byte)0);
        return System.Text.Encoding.ASCII.GetString(z >= 0 ? a[..z] : a).Trim();
    }

    public static (int X, int Y) ParseDpi(RazerReport r) =>
        ((r.Args[1] << 8) | r.Args[2], (r.Args[3] << 8) | r.Args[4]);

    /// <summary>
    /// Response (razer_attr_read_dpi_stages): args[0] varstore, args[1] active stage (1-based),
    /// args[2] count, then per stage at args[3 + 7i]: [stage#, Xhi, Xlo, Yhi, Ylo, 0, 0].
    /// </summary>
    public static (int Active, List<(int X, int Y)> Stages) ParseDpiStages(RazerReport r)
    {
        var a = r.Args;
        int count = Math.Min((int)a[2], MaxDpiStages);
        var list = new List<(int, int)>(count);
        for (int i = 0; i < count; i++)
        {
            int o = 4 + 7 * i;
            if (o + 4 > Math.Min((int)r.DataSize, RazerReport.ArgsLength)) break; // same bound check as OpenRazer
            list.Add(((a[o] << 8) | a[o + 1], (a[o + 2] << 8) | a[o + 3]));
        }
        return (a[1], list);
    }

    /// <summary>Decode table from razer_attr_read_poll_rate (polling_rate2 branch). 0x20 → 250 comes from
    /// the matching set-builder table; it is not in the read table.</summary>
    public static int? DecodePollRate(byte code) => code switch
    {
        0x01 => 8000, 0x02 => 4000, 0x04 => 2000, 0x08 => 1000, 0x10 => 500, 0x20 => 250, 0x40 => 125, _ => null,
    };

    public static int? ParsePollRate(RazerReport r) => DecodePollRate(r.Args[1]);
}
