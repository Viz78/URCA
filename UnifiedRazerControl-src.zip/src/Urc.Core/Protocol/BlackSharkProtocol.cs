namespace Urc.Core.Protocol;

/// <summary>
/// Razer BlackShark V2 Pro (2023) 2.4 GHz dongle, USB 1532:0555 — vendor HID protocol.
///
/// Sources (GPL-2.0-or-later, reimplemented, not copied):
///  * AbdullahSAhmad/blackshark-control blackshark/protocol.py — user-space client, tested on firmware 2.5.
///  * openrazer/openrazer PR #2862 (OPEN, not merged) driver/razerblackshark_driver.{c,h} — derived from
///    Synapse USB captures of this exact device.
///
/// Transport: 64-byte reports with report ID 0x02 on the dongle's vendor collection (usage page 0xFF00).
/// Requests are OUTPUT reports (interrupt OUT), replies and unsolicited events are INPUT reports.
/// On Windows: WriteFile / ReadFile on that collection. Requires OutputReportByteLength == 64.
///
/// Request : [0]=0x02 [1]=0x80 [2]=8+len [5]='P' [6]='A' [7]=0x08 [9]=type [10]=cmd [11]=0 [12]=len [13..]=payload
/// Remote  : [0]=0x02 [1]=0x80 [2]=0x07 [5]='P' [6]='A' [7]=0x0E [9]=0x02 [10]=0xE1 [11]=on/off
/// Reply   : [0]=0x02 ... [12]=cmd [13]=0x01 (ACK) [14]=len [15..]=payload
///
/// Notes from PR #2862: the 2.4 GHz link dozes after ~0.3 s idle and drops the first frame sent into a dozing
/// link (hence the "sacrificial" remote frame); an ACK does not by itself mean a setting took effect
/// (always read back); the EQ button sends an unsolicited 0x13 reply-shaped frame when it cycles presets.
/// </summary>
public static class BlackSharkProtocol
{
    public const ushort ProductId = 0x0555;
    public const byte ReportId = 0x02;
    public const int ReportLength = 64;

    public const byte TypeRemote = 0x02, TypeQuery = 0x03, TypeAudio = 0x04, TypeEq = 0x0D;

    // Read (query) command ids.
    public const byte CmdSerial = 0x00, CmdFirmware = 0x02, CmdPresetGet = 0x13, CmdEqGet = 0x15,
                      CmdSidetoneGet = 0x18, CmdSidetoneLevelGet = 0x19, CmdLink = 0x20, CmdBattery = 0x21,
                      CmdDndGet = 0x27, CmdCharging = 0x2A, CmdIdleGet = 0x2C, CmdMicMute = 0x55;
    public const byte CmdRemote = 0xE1;

    // EQ presets (protocol.py PRESETS; same values in PR #2862 raw_event handling).
    public const byte PresetGame = 0x07, PresetMusic = 0x08, PresetMovie = 0x09, PresetCustom = 0xFF;

    public static readonly IReadOnlyDictionary<byte, string> PresetNames = new Dictionary<byte, string>
    {
        [0x07] = "Game", [0x08] = "Music", [0x09] = "Movie", [0xFF] = "Custom",
        [0xFA] = "Esports 1", [0xFE] = "Esports 2", [0xFB] = "Esports 3", [0xFD] = "Esports 4", [0xFC] = "Esports 5",
    };
    public static readonly string[] EqBands = ["31", "63", "125", "250", "500", "1k", "2k", "4k", "8k", "16k"];

    public static string PresetName(byte p) => PresetNames.TryGetValue(p, out var n) ? n : $"unknown (0x{p:X2})";

    public static byte[] Frame(byte type, byte cmd, ReadOnlySpan<byte> payload = default)
    {
        if (payload.Length > ReportLength - 13) throw new ArgumentException("Payload too long.");
        var b = new byte[ReportLength];
        b[0] = ReportId;
        b[1] = 0x80;
        b[2] = (byte)(8 + payload.Length);
        b[5] = (byte)'P';
        b[6] = (byte)'A';
        b[7] = 0x08;
        b[9] = type;
        b[10] = cmd;
        b[12] = (byte)payload.Length;
        payload.CopyTo(b.AsSpan(13));
        return b;
    }

    public static byte[] Remote(bool on)
    {
        var b = new byte[ReportLength];
        b[0] = ReportId;
        b[1] = 0x80;
        b[2] = 0x07;
        b[5] = (byte)'P';
        b[6] = (byte)'A';
        b[7] = 0x0E;
        b[9] = TypeRemote;
        b[10] = CmdRemote;
        b[11] = on ? (byte)1 : (byte)0;
        return b;
    }

    public static byte[] Query(byte cmd) => Frame(TypeQuery, cmd);

    /// <summary>A reply or unsolicited event: report ID 2, ACK flag at [13]. Returns (cmd, payload).</summary>
    public static bool TryParseReply(ReadOnlySpan<byte> data, out byte cmd, out byte[] payload)
    {
        cmd = 0;
        payload = [];
        if (data.Length <= 15 || data[0] != ReportId || data[13] != 0x01) return false;
        cmd = data[12];
        int n = Math.Min(data[14], data.Length - 15);
        payload = data.Slice(15, n).ToArray();
        return true;
    }

    public static int[] ParseEq(ReadOnlySpan<byte> payload)
    {
        int n = Math.Min(payload.Length, EqBands.Length);
        var r = new int[n];
        for (int i = 0; i < n; i++) r[i] = (sbyte)payload[i];
        return r;
    }
}
