namespace Urc.Core.Protocol;

/// <summary>
/// The 90-byte Razer control report, as a 91-byte Windows feature report (byte 0 = HID report ID 0).
///
/// Layout (OpenRazer driver/razercommon.h, struct razer_report; offsets below are in the Windows buffer):
///   [1] status  [2] transaction id  [3..4] remaining packets (BE)  [5] protocol type
///   [6] data size  [7] command class  [8] command id  [9..88] arguments (80)  [89] CRC  [90] reserved
/// CRC = XOR of razer_report bytes 2..87 (OpenRazer razer_calculate_crc) = Windows buffer bytes 3..88.
///
/// This is a clean C# reimplementation from the documented layout; no OpenRazer code is copied.
/// </summary>
public readonly struct RazerReport
{
    public const int WindowsLength = 91;
    public const int ArgsLength = 80;

    public const int OffStatus = 1, OffTxId = 2, OffRemaining = 3, OffProtocol = 5, OffSize = 6,
                     OffClass = 7, OffCmd = 8, OffArgs = 9, OffCrc = 89;

    public enum Status : byte
    {
        New = 0x00, Busy = 0x01, Successful = 0x02, Failure = 0x03, Timeout = 0x04, NotSupported = 0x05,
    }

    private readonly byte[] _buf;
    public RazerReport(byte[] windowsBuffer)
    {
        if (windowsBuffer.Length != WindowsLength) throw new ArgumentException($"Expected {WindowsLength} bytes.");
        _buf = windowsBuffer;
    }

    public static RazerReport Request(byte transactionId, byte commandClass, byte commandId, byte dataSize, params byte[] args)
    {
        if (args.Length > ArgsLength || dataSize > ArgsLength) throw new ArgumentException("Too many arguments.");
        var b = new byte[WindowsLength];
        b[OffTxId] = transactionId;
        b[OffSize] = dataSize;
        b[OffClass] = commandClass;
        b[OffCmd] = commandId;
        args.CopyTo(b, OffArgs);
        b[OffCrc] = Crc(b);
        return new RazerReport(b);
    }

    public static byte Crc(ReadOnlySpan<byte> windowsBuffer)
    {
        byte c = 0;
        for (int i = 3; i <= 88; i++) c ^= windowsBuffer[i];
        return c;
    }

    public byte[] Buffer => _buf;
    public Status ReportStatus => (Status)_buf[OffStatus];
    public byte TransactionId => _buf[OffTxId];
    public byte DataSize => _buf[OffSize];
    public byte CommandClass => _buf[OffClass];
    public byte CommandId => _buf[OffCmd];
    public ReadOnlySpan<byte> Args => _buf.AsSpan(OffArgs, ArgsLength);
    public bool CrcValid => _buf[OffCrc] == Crc(_buf);

    /// <summary>
    /// OpenRazer's acceptance rule (razermouse_driver.c razer_send_payload): remaining packets, class and
    /// command must echo the request; status Successful, or Busy ("some commands respond busy but succeed").
    /// </summary>
    public bool Matches(RazerReport request) =>
        _buf[OffRemaining] == request._buf[OffRemaining] && _buf[OffRemaining + 1] == request._buf[OffRemaining + 1] &&
        CommandClass == request.CommandClass && CommandId == request.CommandId;

    public string ToHex(int argBytes = 16) =>
        $"st={_buf[OffStatus]:X2} tx={TransactionId:X2} size={DataSize:X2} class={CommandClass:X2} cmd={CommandId:X2} " +
        $"args={Convert.ToHexString(_buf, OffArgs, Math.Min(argBytes, ArgsLength))} crc={_buf[OffCrc]:X2}{(CrcValid ? "" : "(bad)")}";
}
