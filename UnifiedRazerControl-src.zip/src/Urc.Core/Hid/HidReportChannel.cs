using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Threading.Channels;
using Microsoft.Win32.SafeHandles;

namespace Urc.Core.Hid;

/// <summary>
/// Interrupt input/output report transport (ReadFile/WriteFile, overlapped) on one vendor collection.
/// A single background thread blocks in the kernel waiting for input reports (no polling, ~0% CPU idle)
/// and pushes copies into a channel. Writes are serialized.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed unsafe class HidReportChannel : IDisposable
{
    private readonly SafeFileHandle _handle;
    private readonly nint _stopEvent;
    private readonly Thread _reader;
    private readonly Channel<byte[]> _inbox = Channel.CreateBounded<byte[]>(
        new BoundedChannelOptions(256) { FullMode = BoundedChannelFullMode.DropOldest, SingleReader = false, SingleWriter = true });
    private readonly object _writeLock = new();
    private volatile bool _disposed;

    public HidCollection Collection { get; }
    /// <summary>Set when the reader thread ended because the device went away (or an unrecoverable error).</summary>
    public bool Disconnected { get; private set; }
    public event Action? DisconnectedEvent;

    private HidReportChannel(HidCollection c, SafeFileHandle h)
    {
        Collection = c;
        _handle = h;
        _stopEvent = Native.CreateEvent(0, true, false, 0);
        _reader = new Thread(ReadLoop) { IsBackground = true, Name = $"hid-read {c.ProductId:X4}" };
        _reader.Start();
    }

    /// <summary>Opens with read/write sharing so other software (including Synapse, if present) keeps access.</summary>
    public static HidReportChannel Open(HidCollection collection)
    {
        if (collection.InputReportLength == 0 || collection.OutputReportLength == 0)
            throw new HidException("Collection has no input or no output reports; refusing to open it as a report channel.");
        var h = Native.CreateFile(collection.Path, Native.GENERIC_READ | Native.GENERIC_WRITE,
            Native.FILE_SHARE_READ | Native.FILE_SHARE_WRITE, 0, Native.OPEN_EXISTING, Native.FILE_FLAG_OVERLAPPED, 0);
        if (h.IsInvalid)
            throw new HidException($"Cannot open {collection.Path} for read/write (Win32 error {Marshal.GetLastPInvokeError()})",
                Marshal.GetLastPInvokeError());
        return new HidReportChannel(collection, h);
    }

    public ChannelReader<byte[]> Inbox => _inbox.Reader;

    /// <summary>Discards every input report received so far.</summary>
    public void Drain(Action<byte[]>? onEach = null)
    {
        while (_inbox.Reader.TryRead(out var r)) onEach?.Invoke(r);
    }

    /// <summary>Writes one output report. Length must equal the collection's OutputReportByteLength.</summary>
    public void Write(ReadOnlySpan<byte> report, int timeoutMs = 1000)
    {
        if (report.Length != Collection.OutputReportLength)
            throw new ArgumentException($"Output report must be exactly {Collection.OutputReportLength} bytes (got {report.Length}).");
        if (Disconnected) throw new HidException("Device disconnected", 1167);

        lock (_writeLock)
        {
            nint ev = Native.CreateEvent(0, true, false, 0);
            var ov = (NativeOverlapped*)NativeMemory.AllocZeroed((nuint)sizeof(NativeOverlapped));
            byte* buf = (byte*)NativeMemory.Alloc((nuint)report.Length);
            try
            {
                report.CopyTo(new Span<byte>(buf, report.Length));
                ov->EventHandle = ev;
                if (!Native.WriteFile(_handle, buf, (uint)report.Length, null, ov))
                {
                    int err = Marshal.GetLastPInvokeError();
                    if (err != Native.ERROR_IO_PENDING) throw new HidException($"WriteFile failed (Win32 error {err})", err);
                    if (Native.WaitForSingleObject(ev, (uint)timeoutMs) != Native.WAIT_OBJECT_0)
                    {
                        Native.CancelIoEx(_handle, ov);
                        Native.GetOverlappedResult(_handle, ov, out _, true); // must complete before buffers are freed
                        throw new HidException("WriteFile timed out", 1460);
                    }
                }
                if (!Native.GetOverlappedResult(_handle, ov, out _, false))
                    throw HidException.FromLastError("WriteFile");
            }
            finally
            {
                NativeMemory.Free(buf);
                NativeMemory.Free(ov);
                Native.CloseHandle(ev);
            }
        }
    }

    private void ReadLoop()
    {
        int len = Collection.InputReportLength;
        nint readEvent = Native.CreateEvent(0, true, false, 0);
        var ov = (NativeOverlapped*)NativeMemory.AllocZeroed((nuint)sizeof(NativeOverlapped));
        byte* buf = (byte*)NativeMemory.Alloc((nuint)len);
        nint* waits = stackalloc nint[2] { readEvent, _stopEvent };
        try
        {
            while (!_disposed)
            {
                Native.ResetEvent(readEvent);
                *ov = default;
                ov->EventHandle = readEvent;
                if (!Native.ReadFile(_handle, buf, (uint)len, null, ov))
                {
                    int err = Marshal.GetLastPInvokeError();
                    if (err != Native.ERROR_IO_PENDING) { MarkDisconnected(); return; }
                    uint w = Native.WaitForMultipleObjects(2, waits, false, Native.INFINITE);
                    if (w != Native.WAIT_OBJECT_0)
                    {
                        Native.CancelIoEx(_handle, ov);
                        Native.GetOverlappedResult(_handle, ov, out _, true);
                        return; // stop requested
                    }
                }
                if (!Native.GetOverlappedResult(_handle, ov, out uint got, false))
                {
                    if (Marshal.GetLastPInvokeError() == Native.ERROR_OPERATION_ABORTED && _disposed) return;
                    MarkDisconnected();
                    return;
                }
                if (got > 0) _inbox.Writer.TryWrite(new ReadOnlySpan<byte>(buf, (int)got).ToArray());
            }
        }
        finally
        {
            NativeMemory.Free(buf);
            NativeMemory.Free(ov);
            Native.CloseHandle(readEvent);
        }
    }

    private void MarkDisconnected()
    {
        if (_disposed) return;
        Disconnected = true;
        _inbox.Writer.TryComplete();
        DisconnectedEvent?.Invoke();
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        Native.SetEvent(_stopEvent);
        _reader.Join(2000);
        _inbox.Writer.TryComplete();
        _handle.Dispose();
        Native.CloseHandle(_stopEvent);
    }
}
