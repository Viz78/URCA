using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using Microsoft.Win32.SafeHandles;

namespace Urc.Core.Hid;

/// <summary>
/// One HID top-level collection as Windows exposes it (one device-interface path per collection).
/// Everything here is read from the HID descriptor through hid.dll; nothing is sent to the device.
/// </summary>
public sealed record HidCollection
{
    public required string Path { get; init; }
    public required ushort VendorId { get; init; }
    public required ushort ProductId { get; init; }
    public ushort? VersionNumber { get; init; }
    /// <summary>USB interface number parsed from the path ("mi_03" → 3); null for single-interface devices.</summary>
    public int? InterfaceNumber { get; init; }
    /// <summary>Top-level collection index from the path ("col02" → 2); null when the interface has one collection.</summary>
    public int? CollectionNumber { get; init; }
    public ushort UsagePage { get; init; }
    public ushort Usage { get; init; }
    public ushort InputReportLength { get; init; }
    public ushort OutputReportLength { get; init; }
    public ushort FeatureReportLength { get; init; }
    public IReadOnlyList<byte> InputReportIds { get; init; } = [];
    public IReadOnlyList<byte> OutputReportIds { get; init; } = [];
    public IReadOnlyList<byte> FeatureReportIds { get; init; } = [];
    public string? Product { get; init; }
    public string? Manufacturer { get; init; }
    /// <summary>Set when the collection could not be opened even with zero access rights.</summary>
    public string? Error { get; init; }

    public bool IsVendorDefined => UsagePage >= 0xFF00;

    public string Describe() =>
        $"MI_{(InterfaceNumber is int i ? i.ToString("X2") : "--")} COL{(CollectionNumber is int c ? c.ToString("D2") : "--")}  " +
        $"UsagePage 0x{UsagePage:X4} Usage 0x{Usage:X4}  In {InputReportLength} Out {OutputReportLength} Feat {FeatureReportLength}" +
        (InputReportIds.Count + OutputReportIds.Count + FeatureReportIds.Count > 0
            ? $"  ReportIDs in[{Ids(InputReportIds)}] out[{Ids(OutputReportIds)}] feat[{Ids(FeatureReportIds)}]" : "");

    private static string Ids(IReadOnlyList<byte> ids) => string.Join(",", ids.Select(b => $"{b:X2}"));

    /// <summary>Parses "...&amp;mi_03..." and "...&amp;col02..." from a HID interface path. Pure; unit-tested.</summary>
    public static (ushort? vid, ushort? pid, int? mi, int? col) ParsePath(string path)
    {
        string p = path.ToLowerInvariant();
        return (Hex4(p, "vid_"), Hex4(p, "pid_"), Hex2(p, "mi_"), Hex2(p, "col"));

        static ushort? Hex4(string s, string tag)
        {
            int i = s.IndexOf(tag, StringComparison.Ordinal);
            return i >= 0 && i + tag.Length + 4 <= s.Length &&
                   ushort.TryParse(s.AsSpan(i + tag.Length, 4), System.Globalization.NumberStyles.HexNumber, null, out var v) ? v : null;
        }
        static int? Hex2(string s, string tag)
        {
            // Match only as a path component ("&mi_03", "&col02"), not e.g. inside the GUID.
            int i = s.IndexOf("&" + tag, StringComparison.Ordinal);
            if (i < 0) return null;
            i += tag.Length + 1;
            return i + 2 <= s.Length && int.TryParse(s.AsSpan(i, 2), System.Globalization.NumberStyles.HexNumber, null, out var v) ? v : null;
        }
    }
}

[SupportedOSPlatform("windows")]
public static unsafe class HidEnumerator
{
    /// <summary>
    /// Lists present HID collections whose path matches VID/PID. Collections of any other device are never opened.
    /// Matching collections are opened with access 0 (metadata only), which Windows allows even for the
    /// mouse collection that the OS itself holds open.
    /// </summary>
    public static List<HidCollection> Enumerate(ushort vendorId, IReadOnlyCollection<ushort> productIds)
    {
        var result = new List<HidCollection>();
        foreach (string path in InterfacePaths())
        {
            var (vid, pid, mi, col) = HidCollection.ParsePath(path);
            if (vid != vendorId || pid is null || !productIds.Contains(pid.Value)) continue;
            result.Add(Describe(path, vid.Value, pid.Value, mi, col));
        }
        return result.OrderBy(c => c.ProductId).ThenBy(c => c.InterfaceNumber ?? -1).ThenBy(c => c.CollectionNumber ?? -1).ToList();
    }

    /// <summary>Cheap presence check (no device is opened). Used for hot-plug polling fallback.</summary>
    public static List<string> InterfacePaths()
    {
        Native.HidD_GetHidGuid(out Guid guid);
        for (int attempt = 0; attempt < 5; attempt++)
        {
            if (Native.CM_Get_Device_Interface_List_Size(out uint len, ref guid, 0, Native.CM_GET_DEVICE_INTERFACE_LIST_PRESENT) != Native.CR_SUCCESS)
                return [];
            var buf = new char[Math.Max(len, 1)];
            uint cr;
            fixed (char* p = buf)
                cr = Native.CM_Get_Device_Interface_List(ref guid, 0, p, (uint)buf.Length, Native.CM_GET_DEVICE_INTERFACE_LIST_PRESENT);
            if (cr == Native.CR_BUFFER_SMALL) continue; // a device arrived between the two calls
            if (cr != Native.CR_SUCCESS) return [];
            return new string(buf).Split('\0', StringSplitOptions.RemoveEmptyEntries).ToList();
        }
        return [];
    }

    /// <summary>Opens a collection with zero access rights: enough for descriptor caps and feature reports.</summary>
    internal static SafeFileHandle OpenMetadata(string path) =>
        Native.CreateFile(path, 0, Native.FILE_SHARE_READ | Native.FILE_SHARE_WRITE, 0, Native.OPEN_EXISTING, 0, 0);

    private static HidCollection Describe(string path, ushort vid, ushort pid, int? mi, int? col)
    {
        using var h = OpenMetadata(path);
        if (h.IsInvalid)
            return new HidCollection { Path = path, VendorId = vid, ProductId = pid, InterfaceNumber = mi, CollectionNumber = col,
                                       Error = $"CreateFile(access=0) failed, Win32 error {Marshal.GetLastPInvokeError()}" };

        var attrs = new Native.HIDD_ATTRIBUTES { Size = sizeof(Native.HIDD_ATTRIBUTES) };
        ushort? version = Native.HidD_GetAttributes(h, ref attrs) ? attrs.VersionNumber : null;

        if (!Native.HidD_GetPreparsedData(h, out nint pp))
            return new HidCollection { Path = path, VendorId = vid, ProductId = pid, VersionNumber = version, InterfaceNumber = mi,
                                       CollectionNumber = col, Error = $"HidD_GetPreparsedData failed, Win32 error {Marshal.GetLastPInvokeError()}" };
        try
        {
            if (Native.HidP_GetCaps(pp, out var caps) != Native.HIDP_STATUS_SUCCESS)
                return new HidCollection { Path = path, VendorId = vid, ProductId = pid, InterfaceNumber = mi, CollectionNumber = col, Error = "HidP_GetCaps failed" };

            return new HidCollection
            {
                Path = path, VendorId = vid, ProductId = pid, VersionNumber = version, InterfaceNumber = mi, CollectionNumber = col,
                UsagePage = caps.UsagePage, Usage = caps.Usage,
                InputReportLength = caps.InputReportByteLength,
                OutputReportLength = caps.OutputReportByteLength,
                FeatureReportLength = caps.FeatureReportByteLength,
                InputReportIds = ReportIds(pp, Native.HidP_Input, caps.NumberInputButtonCaps, caps.NumberInputValueCaps),
                OutputReportIds = ReportIds(pp, Native.HidP_Output, caps.NumberOutputButtonCaps, caps.NumberOutputValueCaps),
                FeatureReportIds = ReportIds(pp, Native.HidP_Feature, caps.NumberFeatureButtonCaps, caps.NumberFeatureValueCaps),
                Product = ReadString(h, product: true),
                Manufacturer = ReadString(h, product: false),
            };
        }
        finally { Native.HidD_FreePreparsedData(pp); }
    }

    /// <summary>Distinct report IDs declared for a report type (from button and value caps).</summary>
    private static byte[] ReportIds(nint pp, int type, ushort buttonCaps, ushort valueCaps)
    {
        var ids = new SortedSet<byte>();
        Collect(buttonCaps, isValue: false);
        Collect(valueCaps, isValue: true);
        return ids.ToArray();

        void Collect(ushort count, bool isValue)
        {
            if (count == 0) return;
            var raw = new byte[count * Native.HIDP_CAPS_ENTRY_SIZE];
            ushort n = count;
            int status;
            fixed (byte* p = raw)
                status = isValue ? Native.HidP_GetValueCaps(type, p, ref n, pp) : Native.HidP_GetButtonCaps(type, p, ref n, pp);
            if (status != Native.HIDP_STATUS_SUCCESS) return;
            for (int i = 0; i < n; i++) ids.Add(raw[i * Native.HIDP_CAPS_ENTRY_SIZE + 2]); // ReportID at offset 2
        }
    }

    private static string? ReadString(SafeFileHandle h, bool product)
    {
        char* buf = stackalloc char[128];
        bool ok = product ? Native.HidD_GetProductString(h, buf, 256) : Native.HidD_GetManufacturerString(h, buf, 256);
        if (!ok) return null;
        var s = new string(buf, 0, 127);
        int z = s.IndexOf('\0');
        return z >= 0 ? s[..z] : s;
    }
}
