using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using Microsoft.Win32.SafeHandles;

namespace Urc.Core.Hid;

/// <summary>
/// Feature-report transport (HidD_SetFeature / HidD_GetFeature) on one collection.
/// Opened with access 0, so it never competes with Windows for the mouse's input reports.
/// Calls are serialized: a Razer request is a set/get pair and interleaving would read another request's answer.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed unsafe class HidFeatureChannel : IDisposable
{
    private readonly SafeFileHandle _handle;
    private readonly object _lock = new();
    public HidCollection Collection { get; }
    public int ReportLength => Collection.FeatureReportLength;

    private HidFeatureChannel(HidCollection collection, SafeFileHandle handle)
    {
        Collection = collection;
        _handle = handle;
    }

    public static HidFeatureChannel Open(HidCollection collection)
    {
        var h = HidEnumerator.OpenMetadata(collection.Path);
        if (h.IsInvalid)
            throw new HidException($"Cannot open {collection.Path} (Win32 error {Marshal.GetLastPInvokeError()})");
        return new HidFeatureChannel(collection, h);
    }

    public void SetFeature(ReadOnlySpan<byte> report)
    {
        if (report.Length != ReportLength)
            throw new ArgumentException($"Feature report must be exactly {ReportLength} bytes (got {report.Length}).");
        lock (_lock)
            fixed (byte* p = report)
                if (!Native.HidD_SetFeature(_handle, p, (uint)report.Length))
                    throw HidException.FromLastError("HidD_SetFeature");
    }

    /// <summary>Reads a feature report. <paramref name="reportId"/> goes in byte 0 as Windows requires.</summary>
    public byte[] GetFeature(byte reportId)
    {
        var buf = new byte[ReportLength];
        buf[0] = reportId;
        lock (_lock)
            fixed (byte* p = buf)
                if (!Native.HidD_GetFeature(_handle, p, (uint)buf.Length))
                    throw HidException.FromLastError("HidD_GetFeature");
        return buf;
    }

    /// <summary>Runs <paramref name="body"/> with exclusive use of the channel (for set+get pairs).</summary>
    public T Exclusive<T>(Func<HidFeatureChannel, T> body)
    {
        lock (_lock) return body(this);
    }

    public void Dispose() => _handle.Dispose();
}

public class HidException : Exception
{
    public int Win32Error { get; }
    public HidException(string message, int win32Error = 0) : base(message) => Win32Error = win32Error;

    /// <summary>ERROR_DEVICE_NOT_CONNECTED (1167), ERROR_FILE_NOT_FOUND (2), ERROR_GEN_FAILURE (31) after unplug.</summary>
    public bool LooksDisconnected => Win32Error is 1167 or 2 or 31 or 1784 or 6;

    internal static HidException FromLastError(string op)
    {
        int e = Marshal.GetLastPInvokeError();
        return new HidException($"{op} failed (Win32 error {e})", e);
    }
}
