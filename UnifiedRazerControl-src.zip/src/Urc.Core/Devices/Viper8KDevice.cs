using System.Runtime.Versioning;
using Urc.Core.Hid;
using Urc.Core.Protocol;

namespace Urc.Core.Devices;

public sealed class DeviceCommandException(string message, RazerReport.Status? status = null) : Exception(message)
{
    public RazerReport.Status? Status { get; } = status;
    public bool NotSupported => Status == RazerReport.Status.NotSupported;
}

/// <summary>
/// Razer Viper 8KHz over its MI_00 feature-report collection. Milestone 1: read-only queries.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class Viper8KDevice : IDisposable
{
    private readonly HidFeatureChannel _channel;
    public HidCollection Collection => _channel.Collection;

    private Viper8KDevice(HidFeatureChannel ch) => _channel = ch;

    /// <summary>
    /// The control collection must be on interface 0 (OpenRazer sends to wIndex 0 for this PID) and declare a
    /// 91-byte feature report (report ID 0 + 90-byte Razer report). Anything else is not touched.
    /// </summary>
    public static HidCollection? SelectControlCollection(IEnumerable<HidCollection> collections) =>
        collections.Where(c => c.ProductId == Viper8KProtocol.ProductId && c.Error is null
                               && c.FeatureReportLength == RazerReport.WindowsLength
                               && (c.InterfaceNumber ?? 0) == 0)
                   .OrderBy(c => c.CollectionNumber ?? 0)
                   .FirstOrDefault();

    public static Viper8KDevice? TryOpen(IEnumerable<HidCollection> collections)
    {
        var c = SelectControlCollection(collections);
        return c is null ? null : new Viper8KDevice(HidFeatureChannel.Open(c));
    }

    /// <summary>Raw log of every exchange, for the diagnostic report.</summary>
    public List<string> Trace { get; } = [];

    /// <summary>
    /// Send one request and wait for its answer. Mirrors OpenRazer's razer_send_payload acceptance rules
    /// (echoed class/cmd/remaining-packets; Successful or Busy) with OpenSynapse's Windows read pacing.
    /// </summary>
    public RazerReport Transact(RazerReport request, int resends = 3) => _channel.Exclusive(ch =>
    {
        RazerReport? busy = null;
        for (int attempt = 0; attempt < resends; attempt++)
        {
            ch.SetFeature(request.Buffer);
            Trace.Add("> " + request.ToHex());
            for (int read = 0; read < 10; read++)
            {
                Thread.Sleep(1 + read * 2);
                var resp = new RazerReport(ch.GetFeature(0));
                if (!resp.Matches(request) || resp.ReportStatus == RazerReport.Status.New) continue; // not our answer yet
                Trace.Add("< " + resp.ToHex());
                switch (resp.ReportStatus)
                {
                    case RazerReport.Status.Successful: return resp;
                    case RazerReport.Status.Busy: busy = resp; continue;
                    case RazerReport.Status.NotSupported:
                        throw new DeviceCommandException($"Command {request.CommandClass:X2}:{request.CommandId:X2} not supported", resp.ReportStatus);
                    case RazerReport.Status.Failure:
                    case RazerReport.Status.Timeout:
                        throw new DeviceCommandException($"Command {request.CommandClass:X2}:{request.CommandId:X2} returned {resp.ReportStatus}", resp.ReportStatus);
                }
            }
            if (busy is RazerReport b) return b; // OpenRazer treats Busy as accepted
        }
        throw new DeviceCommandException($"No matching answer to {request.CommandClass:X2}:{request.CommandId:X2}");
    });

    public string FirmwareVersion() => Viper8KProtocol.ParseFirmware(Transact(Viper8KProtocol.GetFirmware()));
    public string Serial() => Viper8KProtocol.ParseSerial(Transact(Viper8KProtocol.GetSerial()));
    public byte DeviceMode() => Transact(Viper8KProtocol.GetDeviceMode()).Args[0];
    public (int X, int Y) Dpi() => Viper8KProtocol.ParseDpi(Transact(Viper8KProtocol.GetDpi()));
    public (int Active, List<(int X, int Y)> Stages) DpiStages() => Viper8KProtocol.ParseDpiStages(Transact(Viper8KProtocol.GetDpiStages()));
    public int? PollRate() => Viper8KProtocol.ParsePollRate(Transact(Viper8KProtocol.GetPollRate()));
    public byte LogoBrightness() => Transact(Viper8KProtocol.GetLogoBrightness()).Args[2];

    /// <summary>Opt-in, unverified on this PID: does the mouse answer the Synapse-4 button-list query?</summary>
    public (bool Answered, string Detail) ProbeButtonList()
    {
        foreach (byte tx in new byte[] { 0x1F, 0xFF })
        {
            var req = Viper8KProtocol.ProbeButtonList();
            req.Buffer[RazerReport.OffTxId] = tx;
            req.Buffer[RazerReport.OffCrc] = RazerReport.Crc(req.Buffer);
            try
            {
                var r = Transact(req, resends: 1);
                int n = r.Args[0];
                return (true, n > 0 && n < RazerReport.ArgsLength
                    ? $"tx {tx:X2}: {n} button ids: {string.Join(",", r.Args.Slice(1, n).ToArray().Select(b => b.ToString("X2")))}"
                    : $"tx {tx:X2}: answered, empty/odd list ({r.ToHex()})");
            }
            catch (DeviceCommandException e) when (e.NotSupported) { return (false, $"tx {tx:X2}: Not Supported"); }
            catch (DeviceCommandException e) { if (tx == 0xFF) return (false, e.Message); }
        }
        return (false, "no answer");
    }

    public void Dispose() => _channel.Dispose();
}
