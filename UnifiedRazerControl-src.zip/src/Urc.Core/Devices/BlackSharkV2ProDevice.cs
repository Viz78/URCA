using System.Runtime.Versioning;
using Urc.Core.Hid;
using Urc.Core.Protocol;
using P = Urc.Core.Protocol.BlackSharkProtocol;

namespace Urc.Core.Devices;

/// <summary>The dongle is present but the headset did not answer (off, or out of range).</summary>
public sealed class HeadsetUnreachableException() : Exception("Headset did not answer (powered off, out of range, or on Bluetooth only?)");

/// <summary>
/// BlackShark V2 Pro (2023) through its 2.4 GHz USB dongle (PID 0555). Bluetooth is a separate link to the
/// PC's own Bluetooth stack and is NOT controlled here; only the dongle's vendor HID collection is used.
/// Milestone 1: read-only queries + passive listening for unsolicited frames.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class BlackSharkV2ProDevice : IDisposable
{
    // Timings from blackshark-control protocol.py (REMOTE_SETTLE, REPLY_TIMEOUT, QUERY_ATTEMPTS).
    private const int RemoteSettleMs = 35, ReplyTimeoutMs = 150, QueryAttempts = 3;

    private readonly HidReportChannel _channel;
    private readonly Thread _dispatcher;
    private readonly object _requestLock = new();
    private readonly object _pendingLock = new();
    private (byte Cmd, TaskCompletionSource<byte[]> Tcs)? _pending;

    public HidCollection Collection => _channel.Collection;
    public bool Disconnected => _channel.Disconnected;
    public List<string> Trace { get; } = [];

    /// <summary>Unsolicited frame (cmd, payload). 0x13 = the headset's button changed the EQ preset.</summary>
    public event Action<byte, byte[]>? UnsolicitedFrame;
    public event Action? DisconnectedEvent;

    private BlackSharkV2ProDevice(HidReportChannel ch)
    {
        _channel = ch;
        _channel.DisconnectedEvent += () => DisconnectedEvent?.Invoke();
        _dispatcher = new Thread(Dispatch) { IsBackground = true, Name = "blackshark-dispatch" };
        _dispatcher.Start();
    }

    /// <summary>
    /// Only the vendor collection (usage page ≥ 0xFF00) with 64-byte input AND output reports and output
    /// report ID 2 qualifies. Audio-class interfaces (MI_00 etc.) and consumer-control collections are ignored.
    /// </summary>
    public static HidCollection? SelectControlCollection(IEnumerable<HidCollection> collections) =>
        collections.FirstOrDefault(c => c.ProductId == P.ProductId && c.Error is null && c.IsVendorDefined
                                        && c.OutputReportLength == P.ReportLength && c.InputReportLength == P.ReportLength
                                        && c.OutputReportIds.Contains(P.ReportId));

    public static BlackSharkV2ProDevice? TryOpen(IEnumerable<HidCollection> collections)
    {
        var c = SelectControlCollection(collections);
        return c is null ? null : new BlackSharkV2ProDevice(HidReportChannel.Open(c));
    }

    private void Dispatch()
    {
        var reader = _channel.Inbox;
        try
        {
            while (reader.WaitToReadAsync().AsTask().GetAwaiter().GetResult())
            {
                while (reader.TryRead(out var data))
                {
                    if (!P.TryParseReply(data, out byte cmd, out byte[] payload)) continue;
                    TaskCompletionSource<byte[]>? match = null;
                    lock (_pendingLock)
                        if (_pending is { } p && p.Cmd == cmd) { match = p.Tcs; _pending = null; }
                    if (match is not null) match.TrySetResult(payload);
                    else UnsolicitedFrame?.Invoke(cmd, payload);
                }
            }
        }
        catch (Exception) { /* channel completed or disposed */ }
    }

    private void Send(byte[] frame)
    {
        _channel.Write(frame);
        Trace.Add("> " + Convert.ToHexString(frame, 0, 16));
    }

    private void Remote(bool on)
    {
        Send(P.Remote(on));
        Thread.Sleep(RemoteSettleMs);
    }

    /// <summary>
    /// Read one register. Sequence as in blackshark-control (mirrors the PR #2862 driver): a sacrificial
    /// remote-on frame wakes a dozing link, then up to 3 × (remote-on, query, wait 150 ms), then remote-off.
    /// The remote on/off frame is part of Synapse's own read sequence; it does not change stored settings.
    /// </summary>
    public byte[] Query(byte cmd)
    {
        lock (_requestLock)
        {
            Remote(true);
            try
            {
                for (int i = 0; i < QueryAttempts; i++)
                {
                    Remote(true);
                    var tcs = new TaskCompletionSource<byte[]>(TaskCreationOptions.RunContinuationsAsynchronously);
                    lock (_pendingLock) _pending = (cmd, tcs);
                    Send(P.Query(cmd));
                    if (tcs.Task.Wait(ReplyTimeoutMs))
                    {
                        Trace.Add($"< {cmd:X2} {Convert.ToHexString(tcs.Task.Result)}");
                        return tcs.Task.Result;
                    }
                    lock (_pendingLock) _pending = null;
                    if (_channel.Disconnected) throw new HidException("Dongle disconnected", 1167);
                }
                throw new HeadsetUnreachableException();
            }
            finally
            {
                if (!_channel.Disconnected) Remote(false);
            }
        }
    }

    private byte QueryByte(byte cmd)
    {
        var r = Query(cmd);
        return r.Length > 0 ? r[0] : throw new DeviceCommandException($"Empty reply to 0x{cmd:X2}");
    }

    public string Firmware() { var f = Query(P.CmdFirmware); return f.Length >= 2 ? $"{f[0]}.{f[1]}" : "?"; }
    public string Serial() => System.Text.Encoding.ASCII.GetString(Query(P.CmdSerial)).TrimEnd('\0').Trim();
    public int Battery() => QueryByte(P.CmdBattery);
    public bool Charging() => QueryByte(P.CmdCharging) != 0;
    public bool MicMuted() => QueryByte(P.CmdMicMute) != 0;
    public byte Preset() => QueryByte(P.CmdPresetGet);
    public int[] Eq() => P.ParseEq(Query(P.CmdEqGet));
    public int Sidetone() => QueryByte(P.CmdSidetoneGet) == 0 ? 0 : QueryByte(P.CmdSidetoneLevelGet);
    public int IdleMinutes() => QueryByte(P.CmdIdleGet);
    public bool BluetoothDnd() => QueryByte(P.CmdDndGet) != 0;

    public void Dispose()
    {
        _channel.Dispose();
        _dispatcher.Join(1000);
    }
}
