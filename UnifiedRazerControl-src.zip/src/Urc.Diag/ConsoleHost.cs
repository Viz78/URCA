using System.Runtime.InteropServices;
using System.Runtime.Versioning;

namespace Urc.Diag;

/// <summary>
/// Detects a double-click launch (Explorer gives the process its own console, so it is the only process
/// attached to it). In that case the window must not vanish the moment the program ends.
/// </summary>
[SupportedOSPlatform("windows")]
internal static unsafe partial class ConsoleHost
{
    [LibraryImport("kernel32.dll", SetLastError = true)]
    private static partial uint GetConsoleProcessList(uint* list, uint count);

    public static bool OwnsConsole()
    {
        try
        {
            uint* ids = stackalloc uint[4];
            return GetConsoleProcessList(ids, 4) == 1;
        }
        catch { return false; }
    }

    public static void PauseBeforeExit()
    {
        Console.WriteLine();
        Console.WriteLine("Press any key to close this window...");
        try { Console.ReadKey(intercept: true); } catch { Console.ReadLine(); }
    }
}
