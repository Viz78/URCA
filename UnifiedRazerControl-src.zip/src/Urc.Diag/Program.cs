using System.Diagnostics;
using System.Runtime.Versioning;
using System.Text.Json;
using Urc.Core.Devices;
using Urc.Core.Hid;
using Urc.Core.Protocol;

namespace Urc.Diag;

/// <summary>
/// Milestone 1 diagnostic: detects both devices, dumps their HID collections, and runs READ-ONLY queries.
/// It never sends a command that changes a setting.
/// </summary>
public static class Program
{
    private const ushort RazerVid = 0x1532;
    private static readonly ushort[] OurPids = [Viper8KProtocol.ProductId, BlackSharkProtocol.ProductId];

    public static int Main(string[] args)
    {
        if (!OperatingSystem.IsWindows())
        {
            Console.Error.WriteLine("urc-diag talks to Windows HID APIs and only runs on Windows 10/11.");
            return 2;
        }
        string cmd = args.Length > 0 ? args[0].ToLowerInvariant() : "scan";
        try
        {
            return cmd switch
            {
                "scan" => Scan(),
                "viper" => Viper(args.Contains("--probe-buttons")),
                "headset" => Headset(),
                "watch" => Watch(args.Length > 1 && int.TryParse(args[1], out int s) ? s : 60),
                "report" => Report(args.Contains("--probe-buttons")),
                _ => Usage(),
            };
        }
        catch (Exception e)
        {
            Console.Error.WriteLine($"error: {e.GetType().Name}: {e.Message}");
            return 1;
        }
    }

    private static int Usage()
    {
        Console.WriteLine("""
            urc-diag scan                  List HID collections of the Viper 8KHz and BlackShark V2 Pro dongle
            urc-diag viper [--probe-buttons]  Read-only queries to the mouse (firmware, DPI, stages, polling, brightness)
            urc-diag headset               Read-only queries to the headset (firmware, battery, EQ preset/curve, ...)
            urc-diag watch [seconds]       Listen for unsolicited headset frames; press the headset's EQ button
            urc-diag report [--probe-buttons] Run everything and write urc-diag-report.json
            """);
        return 0;
    }

    [SupportedOSPlatform("windows")]
    private static List<HidCollection> Collections() => HidEnumerator.Enumerate(RazerVid, OurPids);

    [SupportedOSPlatform("windows")]
    private static int Scan()
    {
        WarnAboutSynapse();
        var all = Collections();
        foreach (ushort pid in OurPids)
        {
            string name = pid == Viper8KProtocol.ProductId ? "Razer Viper 8KHz" : "Razer BlackShark V2 Pro (2.4 GHz dongle)";
            var mine = all.Where(c => c.ProductId == pid).ToList();
            Console.WriteLine($"\n== {name}  1532:{pid:X4}  — {(mine.Count == 0 ? "NOT FOUND" : $"{mine.Count} HID collection(s)")}");
            foreach (var c in mine)
            {
                Console.WriteLine($"   {c.Describe()}");
                if (c.Product is not null) Console.WriteLine($"      product \"{c.Product}\"  manufacturer \"{c.Manufacturer}\"  bcdDevice {c.VersionNumber:X4}");
                if (c.Error is not null) Console.WriteLine($"      ! {c.Error}");
                Console.WriteLine($"      {c.Path}");
            }
            var sel = pid == Viper8KProtocol.ProductId ? Viper8KDevice.SelectControlCollection(mine) : BlackSharkV2ProDevice.SelectControlCollection(mine);
            Console.WriteLine(sel is null
                ? "   -> no collection matches the expected control interface; nothing will be sent to this device."
                : $"   -> control collection: {sel.Describe()}");
        }

        // Other Razer devices are listed by path only; they are never opened.
        var others = HidEnumerator.InterfacePaths()
            .Select(p => (p, HidCollection.ParsePath(p)))
            .Where(x => x.Item2.vid == RazerVid && x.Item2.pid is ushort pid && !OurPids.Contains(pid))
            .Select(x => x.Item2.pid!.Value).Distinct().ToList();
        if (others.Count > 0)
            Console.WriteLine($"\nOther Razer PIDs present (not opened): {string.Join(", ", others.Select(p => p.ToString("X4")))}");
        return 0;
    }

    [SupportedOSPlatform("windows")]
    private static int Viper(bool probeButtons)
    {
        using var dev = Viper8KDevice.TryOpen(Collections());
        if (dev is null) { Console.WriteLine("Viper 8KHz control collection not found (run 'urc-diag scan')."); return 1; }
        Console.WriteLine($"Using {dev.Collection.Describe()}");
        Step("Firmware", () => dev.FirmwareVersion());
        Step("Serial", () => dev.Serial());
        Step("Device mode", () => { var m = dev.DeviceMode(); return $"0x{m:X2} ({(m == 0 ? "normal" : m == 3 ? "driver" : "other")})"; });
        Step("DPI (current)", () => { var (x, y) = dev.Dpi(); return $"{x} x {y}"; });
        Step("DPI stages", () =>
        {
            var (active, stages) = dev.DpiStages();
            return $"active {active} of {stages.Count}: " + string.Join("  ", stages.Select((s, i) => $"[{i + 1}] {s.X}x{s.Y}"));
        });
        Step("Polling rate", () => dev.PollRate() is int hz ? $"{hz} Hz" : "unknown code");
        Step("Logo brightness", () => $"{dev.LogoBrightness()} / 255");
        if (probeButtons) Step("Button list probe (unverified, read-only)", () => { var (ok, d) = dev.ProbeButtonList(); return (ok ? "ANSWERED " : "no: ") + d; });
        PrintTrace(dev.Trace);
        return 0;
    }

    [SupportedOSPlatform("windows")]
    private static int Headset()
    {
        using var dev = BlackSharkV2ProDevice.TryOpen(Collections());
        if (dev is null) { Console.WriteLine("BlackShark dongle control collection not found (run 'urc-diag scan')."); return 1; }
        Console.WriteLine($"Using {dev.Collection.Describe()}");
        dev.UnsolicitedFrame += (c, p) => Console.WriteLine($"   (unsolicited frame cmd 0x{c:X2} payload {Convert.ToHexString(p)})");
        Step("Firmware", dev.Firmware);
        Step("Serial", dev.Serial);
        Step("Battery", () => $"{dev.Battery()} %");
        Step("Charging", () => dev.Charging().ToString());
        Step("EQ preset", () => BlackSharkProtocol.PresetName(dev.Preset()));
        Step("EQ curve (active slot)", () => string.Join("  ", dev.Eq().Select((v, i) => $"{BlackSharkProtocol.EqBands[i]}:{v:+0;-0;0}")));
        Step("Mic muted", () => dev.MicMuted().ToString());
        Step("Mic monitoring", () => dev.Sidetone() is int s && s > 0 ? $"level {s}" : "off");
        Step("Auto power-off", () => dev.IdleMinutes() is int m && m > 0 ? $"{m} min" : "never");
        Step("Bluetooth DND", () => dev.BluetoothDnd().ToString());
        PrintTrace(dev.Trace);
        return 0;
    }

    [SupportedOSPlatform("windows")]
    private static int Watch(int seconds)
    {
        using var dev = BlackSharkV2ProDevice.TryOpen(Collections());
        if (dev is null) { Console.WriteLine("BlackShark dongle control collection not found."); return 1; }
        Console.WriteLine($"Listening {seconds}s on {dev.Collection.Describe()} — press the headset's EQ/SmartSwitch button now.");
        Console.WriteLine("(Passive: nothing is sent to the headset.)");
        int n = 0;
        dev.UnsolicitedFrame += (c, p) =>
        {
            n++;
            string what = c == BlackSharkProtocol.CmdPresetGet && p.Length > 0 ? $"EQ preset changed -> {BlackSharkProtocol.PresetName(p[0])}" : "other";
            Console.WriteLine($"{DateTime.Now:HH:mm:ss.fff}  cmd 0x{c:X2}  payload {Convert.ToHexString(p)}  [{what}]");
        };
        dev.DisconnectedEvent += () => Console.WriteLine($"{DateTime.Now:HH:mm:ss.fff}  DONGLE DISCONNECTED");
        var end = DateTime.UtcNow.AddSeconds(seconds);
        while (DateTime.UtcNow < end && !dev.Disconnected) Thread.Sleep(200);
        Console.WriteLine($"Done. {n} unsolicited frame(s).");
        return 0;
    }

    [SupportedOSPlatform("windows")]
    private static int Report(bool probeButtons)
    {
        string path = Path.GetFullPath("urc-diag-report.json");
        var sw = new StringWriter();
        Console.SetOut(sw);
        try
        {
            Console.WriteLine($"urc-diag {typeof(Program).Assembly.GetName().Version}  {Environment.OSVersion}  {DateTime.Now:O}");
            Scan(); Console.WriteLine(); Viper(probeButtons); Console.WriteLine(); Headset();
        }
        catch (Exception e) { Console.WriteLine($"error: {e}"); }
        finally { Console.SetOut(new StreamWriter(Console.OpenStandardOutput()) { AutoFlush = true }); }

        using (var fs = File.Create(path))
        using (var w = new Utf8JsonWriter(fs, new JsonWriterOptions { Indented = true }))
        {
            w.WriteStartObject();
            w.WriteString("generated", DateTime.Now.ToString("O"));
            w.WriteStartArray("collections");
            foreach (var c in Collections())
            {
                w.WriteStartObject();
                w.WriteString("pid", c.ProductId.ToString("X4"));
                w.WriteString("interface", c.InterfaceNumber?.ToString("X2"));
                w.WriteString("collection", c.CollectionNumber?.ToString());
                w.WriteString("usagePage", c.UsagePage.ToString("X4"));
                w.WriteString("usage", c.Usage.ToString("X4"));
                w.WriteNumber("input", c.InputReportLength);
                w.WriteNumber("output", c.OutputReportLength);
                w.WriteNumber("feature", c.FeatureReportLength);
                w.WriteString("inputIds", Convert.ToHexString(c.InputReportIds.ToArray()));
                w.WriteString("outputIds", Convert.ToHexString(c.OutputReportIds.ToArray()));
                w.WriteString("featureIds", Convert.ToHexString(c.FeatureReportIds.ToArray()));
                w.WriteString("product", c.Product);
                w.WriteString("error", c.Error);
                w.WriteEndObject();
            }
            w.WriteEndArray();
            w.WriteString("log", sw.ToString());
            w.WriteEndObject();
        }
        Console.WriteLine(sw.ToString());
        Console.WriteLine($"Report written to {path} (contains device serial numbers; redact them before sharing publicly).");
        return 0;
    }

    private static void Step(string label, Func<string> f)
    {
        try { Console.WriteLine($"  {label,-28} {f()}"); }
        catch (Exception e) { Console.WriteLine($"  {label,-28} FAILED: {e.GetType().Name}: {e.Message}"); }
    }

    private static void PrintTrace(List<string> trace)
    {
        Console.WriteLine("  -- raw exchange trace --");
        foreach (var t in trace) Console.WriteLine("    " + t);
    }

    /// <summary>Synapse writes the same settings; report (never stop) its processes.</summary>
    private static void WarnAboutSynapse()
    {
        string[] names = ["Razer Synapse", "RazerAppEngine", "Razer Synapse Service", "Razer Central", "RazerCentralService", "Razer Synapse 3", "RzSynapse"];
        var running = Process.GetProcesses()
            .Select(p => { try { return p.ProcessName; } catch { return ""; } })
            .Where(n => names.Any(x => n.StartsWith(x, StringComparison.OrdinalIgnoreCase)))
            .Distinct().ToList();
        if (running.Count > 0)
            Console.WriteLine($"Note: Razer software is running ({string.Join(", ", running)}). Reads are fine; for later write tests quit Synapse first so the two don't overwrite each other.");
    }
}
