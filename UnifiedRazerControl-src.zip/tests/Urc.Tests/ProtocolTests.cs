using Urc.Core.Hid;
using Urc.Core.Protocol;
using Xunit;

namespace Urc.Tests;

public class RazerReportTests
{
    [Fact]
    public void FirmwareRequest_HasOpenRazerLayout()
    {
        var r = Viper8KProtocol.GetFirmware().Buffer;
        Assert.Equal(91, r.Length);
        Assert.Equal(0x00, r[0]);           // HID report id
        Assert.Equal(0x00, r[1]);           // status
        Assert.Equal(0xFF, r[2]);           // transaction id for PID 0091
        Assert.Equal(0x02, r[6]);           // data size
        Assert.Equal(0x00, r[7]);           // class
        Assert.Equal(0x81, r[8]);           // command
        Assert.Equal(0x02 ^ 0x00 ^ 0x81, r[89]); // CRC = xor of bytes 3..88
    }

    [Fact]
    public void Crc_MatchesOpenRazerDefinition()
    {
        // OpenRazer: crc ^= report[i] for i in 2..87 of the 90-byte struct == Windows buffer 3..88.
        var req = Viper8KProtocol.GetLogoBrightness();
        byte expect = 0;
        for (int i = 2; i < 88; i++) expect ^= req.Buffer[i + 1];
        Assert.Equal(expect, req.Buffer[RazerReport.OffCrc]);
        Assert.True(req.CrcValid);
    }

    [Fact]
    public void PerCommandTransactionIds_MatchOpenSynapseCatalogFor0091()
    {
        Assert.Equal(0x1F, Viper8KProtocol.GetPollRate().TransactionId);
        Assert.Equal(0x1F, Viper8KProtocol.GetLogoBrightness().TransactionId);
        Assert.Equal(0xFF, Viper8KProtocol.GetDpi().TransactionId);
        Assert.Equal(0xFF, Viper8KProtocol.GetDpiStages().TransactionId);
        Assert.Equal(0xFF, Viper8KProtocol.GetSerial().TransactionId);
    }

    [Fact]
    public void AllMilestone1MouseCommandsAreGets()
    {
        // Razer convention: command id with bit 7 set is a read. Milestone 1 must send nothing else.
        foreach (var r in new[] { Viper8KProtocol.GetFirmware(), Viper8KProtocol.GetSerial(), Viper8KProtocol.GetDeviceMode(),
                                  Viper8KProtocol.GetDpi(), Viper8KProtocol.GetDpiStages(), Viper8KProtocol.GetPollRate(),
                                  Viper8KProtocol.GetLogoBrightness(), Viper8KProtocol.ProbeButtonList() })
            Assert.True((r.CommandId & 0x80) != 0, $"{r.CommandClass:X2}:{r.CommandId:X2} is not a GET");
    }

    private static RazerReport Response(byte cls, byte cmd, byte status, params byte[] args)
    {
        var b = new byte[91];
        b[1] = status; b[7] = cls; b[8] = cmd; b[6] = (byte)args.Length;
        args.CopyTo(b, 9);
        b[89] = RazerReport.Crc(b);
        return new RazerReport(b);
    }

    [Fact]
    public void ParsesDpiStages_LayoutFromOpenRazerComment()
    {
        // Example from razer_attr_read_dpi_stages: 01 02 04 | 01 0320 0320 0000 | 02 0708 0708 0000 ...
        var args = new byte[] { 0x01, 0x02, 0x02,  0x01, 0x03, 0x20, 0x03, 0x20, 0, 0,  0x02, 0x07, 0x08, 0x07, 0x08, 0, 0 };
        var resp = Response(0x04, 0x86, 0x02, args);
        resp.Buffer[RazerReport.OffSize] = 0x26;
        var (active, stages) = Viper8KProtocol.ParseDpiStages(resp);
        Assert.Equal(2, active);
        Assert.Equal([(800, 800), (1800, 1800)], stages);
    }

    [Fact]
    public void ParsesDpiAndFirmware()
    {
        Assert.Equal((1600, 1200), Viper8KProtocol.ParseDpi(Response(0x04, 0x85, 2, 0x00, 0x06, 0x40, 0x04, 0xB0)));
        Assert.Equal("v1.3", Viper8KProtocol.ParseFirmware(Response(0x00, 0x81, 2, 1, 3)));
    }

    [Theory]
    [InlineData(0x01, 8000)] [InlineData(0x02, 4000)] [InlineData(0x04, 2000)]
    [InlineData(0x08, 1000)] [InlineData(0x10, 500)] [InlineData(0x40, 125)]
    public void DecodesPollRate(byte code, int hz) => Assert.Equal(hz, Viper8KProtocol.DecodePollRate(code));

    [Fact]
    public void ResponseMatching_RequiresEchoedClassAndCommand()
    {
        var req = Viper8KProtocol.GetDpi();
        Assert.True(Response(0x04, 0x85, 2).Matches(req));
        Assert.False(Response(0x04, 0x86, 2).Matches(req));
    }
}

public class BlackSharkProtocolTests
{
    [Fact]
    public void QueryFrame_MatchesBlackSharkControlLayout()
    {
        var f = BlackSharkProtocol.Query(BlackSharkProtocol.CmdBattery);
        Assert.Equal(64, f.Length);
        Assert.Equal(new byte[] { 0x02, 0x80, 0x08, 0, 0, (byte)'P', (byte)'A', 0x08, 0, 0x03, 0x21, 0x00, 0x00 }, f[..13]);
        Assert.All(f[13..], b => Assert.Equal(0, b));
    }

    [Fact]
    public void RemoteFrame_MatchesBlackSharkControlLayout()
    {
        var f = BlackSharkProtocol.Remote(true);
        Assert.Equal(new byte[] { 0x02, 0x80, 0x07, 0, 0, (byte)'P', (byte)'A', 0x0E, 0, 0x02, 0xE1, 0x01 }, f[..12]);
        Assert.Equal(0, BlackSharkProtocol.Remote(false)[11]);
    }

    [Fact]
    public void FrameWithPayload_SetsLengths()
    {
        var f = BlackSharkProtocol.Frame(BlackSharkProtocol.TypeAudio, 0x93, [0x07]);
        Assert.Equal(9, f[2]);
        Assert.Equal(1, f[12]);
        Assert.Equal(0x07, f[13]);
    }

    [Fact]
    public void ParsesReplyAndUnsolicitedPresetEvent()
    {
        var d = new byte[64];
        d[0] = 0x02; d[12] = 0x13; d[13] = 0x01; d[14] = 0x01; d[15] = 0x08;
        Assert.True(BlackSharkProtocol.TryParseReply(d, out byte cmd, out byte[] payload));
        Assert.Equal(0x13, cmd);
        Assert.Equal("Music", BlackSharkProtocol.PresetName(payload[0]));

        d[13] = 0x00; // not an ACK frame
        Assert.False(BlackSharkProtocol.TryParseReply(d, out _, out _));
    }

    [Fact]
    public void ParsesSignedEq()
    {
        Assert.Equal([3, -2, 0, 12, -12], BlackSharkProtocol.ParseEq([0x03, 0xFE, 0x00, 0x0C, 0xF4]));
    }
}

public class HidPathTests
{
    [Theory]
    [InlineData(@"\\?\hid#vid_1532&pid_0091&mi_00#7&2a1b3c4&0&0000#{4d1e55b2-f16f-11cf-88cb-001111000030}", 0x0091, 0, null)]
    [InlineData(@"\\?\HID#VID_1532&PID_0555&MI_03&Col02#8&1f&0&0001#{4d1e55b2-f16f-11cf-88cb-001111000030}", 0x0555, 3, 2)]
    [InlineData(@"\\?\hid#vid_1532&pid_0091#6&abc&0&0000#{4d1e55b2-f16f-11cf-88cb-001111000030}", 0x0091, null, null)]
    public void ParsesInterfaceAndCollection(string path, int pid, int? mi, int? col)
    {
        var (v, p, m, c) = HidCollection.ParsePath(path);
        Assert.Equal((ushort)0x1532, v);
        Assert.Equal((ushort)pid, p);
        Assert.Equal(mi, m);
        Assert.Equal(col, c);
    }
}
